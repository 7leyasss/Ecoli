"""Интерфейс: загрузить микроскопическое изображение -> Prediction / Confidence / Status.

    python app.py
"""
import gradio as gr

from src.predict import EcoliClassifier

clf = EcoliClassifier("models")


def run(image):
    if image is None:
        return "—", "—", "—", "Загрузите изображение."
    r = clf.predict(image)
    conf = "—" if r["confidence"] is None else f"{r['confidence']:.0%}"
    return r["prediction"], conf, r["status"], r["message"]


demo = gr.Interface(
    fn=run,
    inputs=gr.Image(type="pil", label="Микроскопическое изображение бактерий"),
    outputs=[gr.Textbox(label="Prediction"), gr.Textbox(label="Confidence"),
             gr.Textbox(label="Status (Result / Uncertain)"), gr.Textbox(label="Comment")],
    title="E. coli vs Not E. coli — исследовательский прототип",
    description=("Загрузите изображение бактерий (оптическая микроскопия). "
                 "Это учебный прототип, а не медицинская или диагностическая система."),
    flagging_mode="never",
)

if __name__ == "__main__":
    demo.launch()
