"""Шаг 3: оценка. Один и тот же скрипт для test-сплита и для независимого набора.

    python -m src.evaluate --manifest data/manifest.csv --split test --name test
    python -m src.evaluate --manifest data/manifest_external.csv --split external --name external

Считаем НЕ только accuracy: при дисбалансе классов она обманчива. Смотрим recall/precision по E. coli,
balanced accuracy, ROC-AUC, PR-AUC, и что делает правило Uncertain (coverage и точность на принятых).
"""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, average_precision_score, balanced_accuracy_score,
                             confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score)

from src.common import apply_rule, get_logits, load_bundle, softmax_T
from src.imgstats import contact_sheet


def bootstrap_ci(y, pred, fn, n=1000, seed=0):
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n):
        idx = rng.integers(0, len(y), len(y))
        if len(set(y[idx])) < 2:
            continue
        vals.append(fn(y[idx], pred[idx]))
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))] if vals else [None, None]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default="data/manifest.csv")
    ap.add_argument("--split", default="test")
    ap.add_argument("--name", default=None)
    ap.add_argument("--model_dir", default="models")
    ap.add_argument("--report_dir", default="reports")
    ap.add_argument("--n_errors", type=int, default=12)
    args = ap.parse_args()
    name = args.name or args.split
    rep = Path(args.report_dir)
    rep.mkdir(exist_ok=True)

    model, meta, device = load_bundle(args.model_dir)
    df = pd.read_csv(args.manifest)
    df = df[df["split"] == args.split].reset_index(drop=True)
    y = df["label"].values.astype(int)
    print(f"{name}: {len(df)} изображений (E. coli: {y.sum()}, Not E. coli: {(1 - y).sum()})")

    logits = get_logits(model, df, meta["img_size"], device)
    p = softmax_T(logits, meta["temperature"])[:, 1]
    pred, conf, unc = apply_rule(p, meta["tau"])
    df["p_ecoli"], df["pred"], df["confidence"], df["uncertain"] = p, pred, conf, unc

    m = {
        "n": int(len(df)), "n_ecoli": int(y.sum()),
        "accuracy": accuracy_score(y, pred),
        "balanced_accuracy": balanced_accuracy_score(y, pred),
        "precision_ecoli": precision_score(y, pred, zero_division=0),
        "recall_ecoli": recall_score(y, pred, zero_division=0),
        "f1_ecoli": f1_score(y, pred, zero_division=0),
        "roc_auc": roc_auc_score(y, p) if len(set(y)) > 1 else None,
        "pr_auc": average_precision_score(y, p) if len(set(y)) > 1 else None,
        "confusion_matrix[[TN,FP],[FN,TP]]": confusion_matrix(y, pred, labels=[0, 1]).tolist(),
        "recall_ecoli_95ci": bootstrap_ci(y, pred, lambda a, b: recall_score(a, b, zero_division=0)),
        "balanced_acc_95ci": bootstrap_ci(y, pred, balanced_accuracy_score),
    }
    keep = ~unc
    m["with_uncertain_rule"] = {
        "tau": meta["tau"], "coverage": float(keep.mean()), "n_uncertain": int(unc.sum()),
        "ecoli_marked_uncertain": int((unc & (y == 1)).sum()),
        "accuracy_on_decided": float(accuracy_score(y[keep], pred[keep])) if keep.any() else None,
        "recall_ecoli_on_decided": float(recall_score(y[keep], pred[keep], zero_division=0)) if keep.any() else None,
        "precision_ecoli_on_decided": float(precision_score(y[keep], pred[keep], zero_division=0)) if keep.any() else None,
    }
    (rep / f"{name}_metrics.json").write_text(json.dumps(m, indent=2, ensure_ascii=False))
    print(json.dumps(m, indent=2, ensure_ascii=False))

    # по видам: где именно ошибается модель
    df["correct"] = (df["pred"] == df["label"]).astype(int)
    per = df.groupby("species").agg(n=("path", "count"), accuracy=("correct", "mean"),
                                    mean_p_ecoli=("p_ecoli", "mean"), share_uncertain=("uncertain", "mean")).round(3)
    per.to_csv(rep / f"{name}_per_species.csv")
    print("\nПо видам:\n", per)

    # матрица ошибок
    cm = confusion_matrix(y, pred, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(3.6, 3.2))
    ax.imshow(cm, cmap="Blues")
    for (i, j), v in np.ndenumerate(cm):
        ax.text(j, i, v, ha="center", va="center")
    ax.set_xticks([0, 1], ["Not E. coli", "E. coli"])
    ax.set_yticks([0, 1], ["Not E. coli", "E. coli"])
    ax.set_xlabel("предсказано")
    ax.set_ylabel("истина")
    ax.set_title(name)
    fig.tight_layout()
    fig.savefig(rep / f"{name}_confusion.png", dpi=150)

    # для разбора ошибок: самые уверенные ошибки и самые неуверенные предсказания
    df.to_csv(rep / f"{name}_predictions.csv", index=False)
    wrong = df[df["correct"] == 0].sort_values("confidence", ascending=False).head(args.n_errors)
    contact_sheet(wrong["path"].tolist(),
                  [f"ERR true={r.label} p={r.p_ecoli:.2f} {r.species}" for r in wrong.itertuples()],
                  rep / f"{name}_top_errors.png")
    unsure = df.sort_values("confidence").head(args.n_errors)
    contact_sheet(unsure["path"].tolist(),
                  [f"true={r.label} p={r.p_ecoli:.2f} {r.species}" for r in unsure.itertuples()],
                  rep / f"{name}_least_confident.png")
    print(f"\nОтчёты: {rep}/{name}_*.json|csv|png")


if __name__ == "__main__":
    main()
