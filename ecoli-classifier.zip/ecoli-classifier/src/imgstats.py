"""Лёгкие утилиты для проверки данных: перцептивный хэш, простые статистики, контактный лист.
Без внешних зависимостей кроме PIL/numpy."""
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def list_images(root):
    return sorted(p for p in Path(root).rglob("*") if p.suffix.lower() in IMG_EXTS)


def _dct_matrix(n):
    k = np.arange(n)[:, None]
    i = np.arange(n)[None, :]
    return np.cos(np.pi * (2 * i + 1) * k / (2 * n))


_DCT32 = _dct_matrix(32)


def phash_bits(img, hash_size=8):
    """DCT-перцептивный хэш (64 бита) -> массив uint8 из 0/1."""
    g = img.convert("L").resize((32, 32), Image.LANCZOS)
    a = np.asarray(g, dtype=np.float64)
    d = _DCT32 @ a @ _DCT32.T
    low = d[:hash_size, :hash_size].flatten()
    med = np.median(low[1:])  # без DC-компоненты
    return (low > med).astype(np.uint8)


def hamming_matrix(a, b=None):
    """Попарные расстояния Хэмминга между наборами битовых хэшей (N,64) и (M,64)."""
    a = a.astype(np.int32)
    b = a if b is None else b.astype(np.int32)
    return a @ (1 - b).T + (1 - a) @ b.T


def image_stats(img):
    """Простые «метаданные картинки», по которым модель могла бы схитрить."""
    w, h = img.size
    im = img.convert("RGB")
    im.thumbnail((256, 256))
    rgb = np.asarray(im, dtype=np.float32)
    gray = rgb.mean(axis=2)
    lap = (4 * gray[1:-1, 1:-1] - gray[:-2, 1:-1] - gray[2:, 1:-1]
           - gray[1:-1, :-2] - gray[1:-1, 2:])
    bh, bw = max(1, gray.shape[0] // 10), max(1, gray.shape[1] // 10)
    border = np.concatenate([gray[:bh].ravel(), gray[-bh:].ravel(),
                             gray[:, :bw].ravel(), gray[:, -bw:].ravel()])
    return {
        "width": w, "height": h, "aspect": w / h,
        "mean_r": float(rgb[..., 0].mean()), "mean_g": float(rgb[..., 1].mean()),
        "mean_b": float(rgb[..., 2].mean()),
        "brightness": float(gray.mean()), "contrast": float(gray.std()),
        "sharpness": float(lap.var()), "border_brightness": float(border.mean()),
    }


def contact_sheet(paths, captions, out_path, thumb=200, cols=4):
    """Сохраняет сетку миниатюр с подписями (для разбора ошибок и просмотра выборки)."""
    if not paths:
        return
    rows = (len(paths) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * thumb, rows * (thumb + 34)), "white")
    draw = ImageDraw.Draw(sheet)
    for i, (p, c) in enumerate(zip(paths, captions)):
        try:
            im = Image.open(p).convert("RGB")
            im.thumbnail((thumb, thumb))
        except Exception:
            continue
        x, y = (i % cols) * thumb, (i // cols) * (thumb + 34)
        sheet.paste(im, (x, y))
        draw.text((x + 3, y + thumb + 2), c[:34], fill="black")
        draw.text((x + 3, y + thumb + 16), c[34:68], fill="black")
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    sheet.save(out_path)
