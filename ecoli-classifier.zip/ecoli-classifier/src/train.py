"""Шаг 2: transfer learning (ImageNet-предобученная сеть) на train, отбор по val.

    python -m src.train --arch resnet18 --epochs 12

Схема: сначала обучаем только «голову» (warmup), затем размораживаем всю сеть с малым lr.
После обучения на ВАЛИДАЦИИ (не на тесте!) подбираем temperature и порог tau для Uncertain.
"""
import argparse
import csv
import random
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import balanced_accuracy_score, roc_auc_score
from torch.utils.data import DataLoader

from src.common import (ManifestDataset, apply_rule, build_model, choose_tau,
                        fit_temperature, get_device, get_logits, make_transform,
                        save_bundle, softmax_T)


def set_seed(s):
    random.seed(s)
    np.random.seed(s)
    torch.manual_seed(s)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default="data/manifest.csv")
    ap.add_argument("--arch", default="resnet18", choices=["resnet18", "efficientnet_b0"])
    ap.add_argument("--img_size", type=int, default=320)
    ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--warmup_epochs", type=int, default=3)
    ap.add_argument("--batch_size", type=int, default=16)
    ap.add_argument("--lr_head", type=float, default=1e-3)
    ap.add_argument("--lr_full", type=float, default=1e-4)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--model_dir", default="models")
    ap.add_argument("--report_dir", default="reports")
    ap.add_argument("--workers", type=int, default=2)
    args = ap.parse_args()

    set_seed(args.seed)
    device = get_device()
    print("device:", device)

    df = pd.read_csv(args.manifest)
    tr, va = df[df.split == "train"], df[df.split == "val"]
    print(f"train={len(tr)} val={len(va)} (test не используется при обучении)")

    dl_tr = DataLoader(ManifestDataset(tr, make_transform(args.img_size, True)),
                       batch_size=args.batch_size, shuffle=True, num_workers=args.workers, drop_last=True)

    model, head_params = build_model(args.arch, pretrained=True)
    model.to(device)

    # веса классов: E. coli обычно в меньшинстве (1 против нескольких видов)
    counts = tr["label"].value_counts().reindex([0, 1]).fillna(1).values
    w = torch.tensor(len(tr) / (2 * counts), dtype=torch.float32, device=device)
    criterion = nn.CrossEntropyLoss(weight=w)

    def set_trainable(full):
        for p in model.parameters():
            p.requires_grad = full
        for p in head_params:
            p.requires_grad = True

    set_trainable(False)
    opt = torch.optim.AdamW(head_params, lr=args.lr_head, weight_decay=1e-4)
    sched = None

    log, best, best_state = [], -1.0, None
    for ep in range(1, args.epochs + 1):
        if ep == args.warmup_epochs + 1:  # размораживаем всё
            set_trainable(True)
            opt = torch.optim.AdamW(model.parameters(), lr=args.lr_full, weight_decay=1e-4)
            sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs - args.warmup_epochs)
        model.train()
        run = 0.0
        for x, y in dl_tr:
            x, y = x.to(device), y.to(device)
            opt.zero_grad()
            loss = criterion(model(x), y)
            loss.backward()
            opt.step()
            run += loss.item() * len(y)
        if sched:
            sched.step()

        lv = get_logits(model, va, args.img_size, device, num_workers=args.workers)
        pv = softmax_T(lv)[:, 1]
        yv = va["label"].values
        bacc = balanced_accuracy_score(yv, (pv >= 0.5).astype(int))
        auc = roc_auc_score(yv, pv) if len(set(yv)) > 1 else float("nan")
        score = auc if not np.isnan(auc) else bacc
        print(f"epoch {ep:02d} | train_loss {run / len(tr):.4f} | val bal.acc {bacc:.3f} | val AUC {auc:.3f}")
        log.append({"epoch": ep, "train_loss": run / len(tr), "val_bal_acc": bacc, "val_auc": auc})
        if score > best:
            best = score
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)

    # --- калибровка и порог Uncertain — ТОЛЬКО по валидации ---
    lv = get_logits(model, va, args.img_size, device, num_workers=args.workers)
    yv = va["label"].values.astype(int)
    T_ = fit_temperature(lv, yv)
    pv = softmax_T(lv, T_)[:, 1]
    tau = choose_tau(pv, yv)
    pred, conf, unc = apply_rule(pv, tau)
    print(f"\ntemperature={T_:.2f}  tau={tau}  | на val: coverage={1 - unc.mean():.2f}, "
          f"acc на принятых={(pred[~unc] == yv[~unc]).mean():.3f}")

    meta = {"arch": args.arch, "img_size": args.img_size, "temperature": T_, "tau": tau,
            "seed": args.seed, "best_val_score": float(best),
            "uncertain_rule": "Uncertain, если max(p_ecoli, 1-p_ecoli) < tau; tau и temperature подобраны на val"}
    save_bundle(model, meta, args.model_dir)
    Path(args.report_dir).mkdir(exist_ok=True)
    with open(Path(args.report_dir) / "train_log.csv", "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=log[0].keys())
        wr.writeheader()
        wr.writerows(log)
    print(f"Модель сохранена в {args.model_dir}/")


if __name__ == "__main__":
    main()
