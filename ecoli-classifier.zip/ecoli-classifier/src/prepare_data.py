"""Шаг 1: собрать манифест, проверить данные, разбить на train/val/test без утечек.

Ожидаемая структура папок (папка класса = вид/род бактерии):
    data/raw/<источник>/<вид>/*.jpg          <- обучающие данные
    data/external/<источник>/<вид>/*.jpg     <- независимый источник (только для финальной проверки)

Что делает скрипт:
  1. собирает манифест (путь, источник, вид, метка E. coli = 1 / Not E. coli = 0);
  2. считает простые статистики картинок (размер, цвет, яркость, резкость, фон);
  3. ищет дубликаты и почти-дубликаты (перцептивный хэш) и объединяет их в группы;
  4. проверяет «читерские» признаки: можно ли угадать класс только по метаданным картинки;
  5. делит данные по ГРУППАМ (дубликаты не попадают в разные сплиты), стратифицируя по виду;
  6. для внешнего набора проверяет, что он не пересекается с обучающим.

Пример:
    python -m src.prepare_data --positive escherichia --external data/external
"""
import argparse
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold, cross_val_predict

from src.imgstats import (contact_sheet, hamming_matrix, image_stats,
                          list_images, phash_bits)

STAT_COLS = ["width", "height", "aspect", "mean_r", "mean_g", "mean_b",
             "brightness", "contrast", "sharpness", "border_brightness"]


def scan(root, positive_keywords):
    """Обходит root/<источник>/<вид>/файл; считает статистики и хэши."""
    root = Path(root)
    rows, bits = [], []
    paths = list_images(root)
    for n, p in enumerate(paths):
        try:
            img = Image.open(p)
            img.load()
        except Exception as e:  # битый файл — тоже результат проверки данных
            print(f"  [битый файл] {p}: {e}")
            continue
        rel = p.relative_to(root).parts
        source = rel[0] if len(rel) >= 3 else root.name
        species = p.parent.name.lower()
        row = {"path": str(p), "source": source, "species": species,
               "label": int(any(k.lower() in species for k in positive_keywords))}
        row.update(image_stats(img))
        row["file_kb"] = p.stat().st_size / 1024
        rows.append(row)
        bits.append(phash_bits(img))
        if (n + 1) % 200 == 0:
            print(f"  обработано {n + 1}/{len(paths)}")
    return pd.DataFrame(rows), np.array(bits)


def group_duplicates(bits, thresh):
    """Union-find по парам с расстоянием Хэмминга <= thresh."""
    n = len(bits)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    dist = hamming_matrix(bits)
    ii, jj = np.where(np.triu(dist <= thresh, k=1))
    for i, j in zip(ii, jj):
        ri, rj = find(i), find(j)
        if ri != rj:
            parent[ri] = rj
    return np.array([find(i) for i in range(n)])


def shortcut_check(df, seed):
    """Может ли простая модель угадать метку по метаданным (без содержимого)? AUC≈0.5 — хорошо."""
    X = df[STAT_COLS + ["file_kb"]].values
    y = df["label"].values
    if len(set(y)) < 2:
        return None
    cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        proba = cross_val_predict(GradientBoostingClassifier(random_state=seed), X, y,
                                  groups=df["group"].values, cv=cv, method="predict_proba")[:, 1]
    return roc_auc_score(y, proba)


def make_split(df, seed):
    """train ~72% / val ~14% / test ~14%, по группам, стратификация по источнику+виду."""
    strat = (df["source"] + "/" + df["species"]).astype("category").cat.codes.values
    groups = df["group"].values
    df["split"] = "train"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        s1 = StratifiedGroupKFold(n_splits=7, shuffle=True, random_state=seed)
        rest_idx, test_idx = next(s1.split(df, strat, groups))
        s2 = StratifiedGroupKFold(n_splits=6, shuffle=True, random_state=seed)
        _, val_rel = next(s2.split(df.iloc[rest_idx], strat[rest_idx], groups[rest_idx]))
    df.loc[df.index[test_idx], "split"] = "test"
    df.loc[df.index[rest_idx[val_rel]], "split"] = "val"
    # страховка: ни одна группа не должна лежать в двух сплитах
    leak = df.groupby("group")["split"].nunique()
    assert (leak == 1).all(), "Группа-дубликат попала в разные сплиты!"
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/raw")
    ap.add_argument("--external", default=None, help="папка с независимым набором (опционально)")
    ap.add_argument("--positive", nargs="+", default=["escherichia", "e.coli", "ecoli", "e_coli"],
                    help="подстроки в названии папки вида, которые означают класс E. coli")
    ap.add_argument("--dup_thresh", type=int, default=6, help="порог Хэмминга (из 64 бит) для дубликатов")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="data/manifest.csv")
    ap.add_argument("--out_external", default="data/manifest_external.csv")
    ap.add_argument("--report_dir", default="reports")
    args = ap.parse_args()
    rep = Path(args.report_dir)
    rep.mkdir(parents=True, exist_ok=True)

    print(f"Сканирую {args.raw} ...")
    df, bits = scan(args.raw, args.positive)
    if df.empty:
        raise SystemExit(f"В {args.raw} нет изображений. Ожидается {args.raw}/<источник>/<вид>/*.jpg")

    print("\n== Состав данных: источник × вид ==")
    print(pd.crosstab([df["source"], df["species"]], df["label"].map({1: "E. coli", 0: "Not E. coli"})))
    xs = pd.crosstab(df["source"], df["label"])
    if (xs > 0).sum(axis=1).min() < 2 and df["source"].nunique() > 1:
        print("\n!! ВНИМАНИЕ: есть источник(и), где присутствует только один класс. "
              "Модель может выучить «источник», а не бактерию.")

    # --- дубликаты ---
    df["group"] = group_duplicates(bits, args.dup_thresh)
    sizes = df.groupby("group")["path"].transform("count")
    dups = df[sizes > 1].sort_values("group")
    dups[["group", "path", "species", "label"]].to_csv(rep / "duplicate_groups.csv", index=False)
    print(f"\n== Дубликаты (порог Хэмминга ≤ {args.dup_thresh}) ==")
    print(f"групп с >1 изображением: {dups['group'].nunique()}, изображений в них: {len(dups)}")
    mixed = df.groupby("group")["label"].nunique()
    if (mixed > 1).any():
        print(f"!! {int((mixed > 1).sum())} групп содержат ОБА класса — проверьте разметку "
              f"(см. reports/duplicate_groups.csv)")

    # --- статистики по классам ---
    summ = df.groupby(["label", "species"])[STAT_COLS + ["file_kb"]].mean().round(2)
    summ.to_csv(rep / "eda_class_stats.csv")
    print("\n== Средние статистики по видам (сохранено в reports/eda_class_stats.csv) ==")
    print(summ[["width", "height", "brightness", "sharpness", "border_brightness"]])
    print("Размеры изображений:", df.groupby(["width", "height"]).size().sort_values(ascending=False).head(5).to_dict())

    # --- проверка читерских признаков ---
    auc = shortcut_check(df, args.seed)
    if auc is not None:
        print(f"\n== Проверка на 'читерство': AUC модели ТОЛЬКО по метаданным = {auc:.3f} ==")
        if auc > 0.75:
            print("!! Высокий AUC: классы различаются по размеру/цвету/яркости/резкости. "
                  "Нужна нормализация/аугментация или другой набор данных. Зафиксируйте это в README.")
        else:
            print("OK: по простым метаданным класс угадать нельзя (или почти нельзя).")
    (rep / "shortcut_check.txt").write_text(f"AUC по метаданным (GroupKFold, GBM): {auc}\n")

    # --- разбиение ---
    df = make_split(df, args.seed)
    print("\n== Разбиение (по группам, стратификация по виду) ==")
    print(pd.crosstab(df["species"], df["split"], margins=True))
    print(pd.crosstab(df["label"].map({1: "E. coli", 0: "Not E. coli"}), df["split"]))

    # --- визуальный просмотр ---
    rng = np.random.default_rng(args.seed)
    picks, caps = [], []
    for sp, g in df.groupby("species"):
        idx = rng.choice(len(g), size=min(4, len(g)), replace=False)
        for i in idx:
            picks.append(g.iloc[i]["path"])
            caps.append(f"{sp} ({g.iloc[i]['source']})")
    contact_sheet(picks, caps, rep / "samples_train_pool.png")

    df.to_csv(args.out, index=False)
    print(f"\nМанифест сохранён: {args.out}")

    # --- внешний набор ---
    if args.external and Path(args.external).exists():
        print(f"\nСканирую независимый набор {args.external} ...")
        ext, ebits = scan(args.external, args.positive)
        if ext.empty:
            print("  (пусто)")
        else:
            ext["split"] = "external"
            d = hamming_matrix(ebits, bits)
            ext["min_hamming_to_train_pool"] = d.min(axis=1)
            n_close = int((ext["min_hamming_to_train_pool"] <= args.dup_thresh).sum())
            print(f"Изображений во внешнем наборе: {len(ext)}; "
                  f"почти-копий обучающих данных (≤{args.dup_thresh}): {n_close}")
            if n_close:
                print("!! Внешний набор пересекается с обучающим — это не независимая проверка. "
                      "Удалите эти файлы или возьмите другой источник.")
            print(pd.crosstab(ext["species"], ext["label"].map({1: "E. coli", 0: "Not E. coli"})))
            ext.to_csv(args.out_external, index=False)
            print(f"Манифест внешнего набора: {args.out_external}")
            print(f"Сравнение статистик train-пула и внешнего набора:")
            cmp = pd.DataFrame({"train_pool": df[STAT_COLS].mean(), "external": ext[STAT_COLS].mean()}).round(1)
            print(cmp)
            cmp.to_csv(rep / "domain_shift_stats.csv")


if __name__ == "__main__":
    main()
