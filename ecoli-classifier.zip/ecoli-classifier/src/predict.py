"""Инференс для одного изображения (используется интерфейсом)."""
import numpy as np
import torch
from PIL import Image

from src.common import CLASS_NAMES, load_bundle, make_transform, softmax_T

MIN_SIDE = 96  # слишком маленькие изображения не классифицируем


class EcoliClassifier:
    def __init__(self, model_dir="models"):
        self.model, self.meta, self.device = load_bundle(model_dir)
        self.tfm = make_transform(self.meta["img_size"], train=False)

    @torch.no_grad()
    def predict(self, img: Image.Image) -> dict:
        img = img.convert("RGB")
        if min(img.size) < MIN_SIDE:
            return {"prediction": "Uncertain", "confidence": None, "p_ecoli": None, "status": "Uncertain",
                    "message": f"Изображение слишком маленькое (< {MIN_SIDE}px по короткой стороне)."}
        x = self.tfm(img).unsqueeze(0).to(self.device)
        logits = self.model(x).cpu().numpy()
        p = float(softmax_T(logits, self.meta["temperature"])[0, 1])
        conf = max(p, 1 - p)
        tau = self.meta["tau"]
        if conf < tau:
            return {"prediction": "Uncertain", "confidence": conf, "p_ecoli": p, "status": "Uncertain",
                    "message": (f"Модель не уверена (уверенность {conf:.0%} < порога {tau:.0%}). "
                                "Возможно, изображение отличается от обучающих данных "
                                "(увеличение, окраска, фон, качество) — нужна проверка человеком.")}
        label = CLASS_NAMES[int(p >= 0.5)]
        return {"prediction": label, "confidence": conf, "p_ecoli": p, "status": "Result",
                "message": "Исследовательский прототип, не диагностический инструмент."}
