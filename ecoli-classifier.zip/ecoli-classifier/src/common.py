"""Общие функции: трансформы, модель, инференс, правило Uncertain."""
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms as T

MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]
CLASS_NAMES = {0: "Not E. coli", 1: "E. coli"}


def get_device():
    if torch.cuda.is_available():
        return torch.device("cuda")
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def make_transform(img_size, train):
    if train:
        # Микроскопия не имеет «верха/низа» -> флипы и повороты безопасны.
        # Небольшой цветовой джиттер и редкий grayscale — чтобы модель не опиралась
        # только на оттенок окраски/освещения (типичный «шорткат» датасета).
        return T.Compose([
            T.RandomResizedCrop(img_size, scale=(0.6, 1.0), ratio=(0.8, 1.25)),
            T.RandomHorizontalFlip(), T.RandomVerticalFlip(),
            T.RandomApply([T.RandomRotation(90)], p=0.5),
            T.ColorJitter(brightness=0.25, contrast=0.25, saturation=0.15, hue=0.02),
            T.RandomGrayscale(p=0.1),
            T.ToTensor(), T.Normalize(MEAN, STD)])
    return T.Compose([T.Resize((img_size, img_size)), T.ToTensor(), T.Normalize(MEAN, STD)])


def build_model(arch, pretrained=True):
    """Возвращает (модель с 2 выходами, параметры «головы»)."""
    if arch == "resnet18":
        m = models.resnet18(weights=models.ResNet18_Weights.DEFAULT if pretrained else None)
        m.fc = nn.Linear(m.fc.in_features, 2)
        return m, list(m.fc.parameters())
    if arch == "efficientnet_b0":
        m = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.DEFAULT if pretrained else None)
        m.classifier[1] = nn.Linear(m.classifier[1].in_features, 2)
        return m, list(m.classifier.parameters())
    raise ValueError(f"unknown arch {arch}")


class ManifestDataset(Dataset):
    def __init__(self, df, transform):
        self.paths = df["path"].tolist()
        self.labels = df["label"].astype(int).tolist()
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, i):
        img = Image.open(self.paths[i]).convert("RGB")
        return self.transform(img), self.labels[i]


@torch.no_grad()
def get_logits(model, df, img_size, device, batch_size=32, num_workers=2):
    model.eval()
    dl = DataLoader(ManifestDataset(df, make_transform(img_size, False)),
                    batch_size=batch_size, shuffle=False, num_workers=num_workers)
    out = []
    for x, _ in dl:
        out.append(model(x.to(device)).cpu())
    return torch.cat(out).numpy()


def softmax_T(logits, temperature=1.0):
    z = logits / temperature
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def fit_temperature(logits, y):
    """Temperature scaling: подбираем T по валидации (минимум NLL), чтобы confidence был честнее."""
    best_t, best_nll = 1.0, 1e9
    for t in np.arange(0.5, 5.01, 0.05):
        p = softmax_T(logits, t)[np.arange(len(y)), y]
        nll = -np.log(np.clip(p, 1e-8, 1)).mean()
        if nll < best_nll:
            best_t, best_nll = float(t), float(nll)
    return best_t


def choose_tau(p_ecoli, y, target_acc=0.95, min_coverage=0.80, min_tau=0.70, default=0.80):
    """Правило Uncertain: confidence = max(p, 1-p) < tau.
    tau = минимальный порог, при котором точность на «принятых» >= target_acc,
    а доля принятых (coverage) >= min_coverage. Нижняя граница min_tau нужна, чтобы правило
    не «выключалось» на маленькой идеальной валидации. Иначе — запасной default."""
    conf = np.maximum(p_ecoli, 1 - p_ecoli)
    pred = (p_ecoli >= 0.5).astype(int)
    for tau in np.arange(min_tau, 0.995, 0.005):
        keep = conf >= tau
        if keep.mean() < min_coverage:
            break
        if (pred[keep] == y[keep]).mean() >= target_acc:
            return float(round(tau, 3))
    return default


def apply_rule(p_ecoli, tau):
    """-> (метка 0/1, confidence, uncertain_mask)"""
    p_ecoli = np.asarray(p_ecoli)
    pred = (p_ecoli >= 0.5).astype(int)
    conf = np.maximum(p_ecoli, 1 - p_ecoli)
    return pred, conf, conf < tau


def save_bundle(model, meta, model_dir="models"):
    Path(model_dir).mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), Path(model_dir) / "model.pt")
    (Path(model_dir) / "meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False))


def load_bundle(model_dir="models", device=None):
    device = device or get_device()
    meta = json.loads((Path(model_dir) / "meta.json").read_text())
    model, _ = build_model(meta["arch"], pretrained=False)
    model.load_state_dict(torch.load(Path(model_dir) / "model.pt", map_location="cpu"))
    return model.to(device).eval(), meta, device
